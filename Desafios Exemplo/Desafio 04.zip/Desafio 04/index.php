<?php

$palavras = array('Visto', 'Ama', 'Amor', 'Arara', 'Reviver');
$cont_palidromas = 0;

echo "<h1>Palavras palíndromas</h1>";

foreach($palavras as $p => $c){
    $a = $c;
    $b = strrev($c);
    
    if($a == $b){
        $cont_palidromas++;
        echo "$c <br/>";
    }
}
echo "Quantidade de palavras palíndromas: $cont_palidromas";
