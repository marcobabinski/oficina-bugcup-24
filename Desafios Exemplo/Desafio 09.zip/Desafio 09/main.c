#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/** 
 * Função auxiliar usada para encontrar um parentese correspondente
 * 
 * @param s String com trecho que expressão iniciando pelo parêntese
 * 
 * @return posição do parêntese de fechamento ou 0 caso não exista 
 */
int findPair(char *s) {
   int count = 0;
   for (int i=0;i<strlen(s);i++) {       //Esta função procura o par do
      if (s[i] == ')') {                 //caractere s[0] e retorna sua posição 
         if (!--count) {                 //Caso não encontre retorna 0 para 
            return i;                    //garantir que uma expressão inválida
         }                               //não cause falha de segmentação. 
      } else if (s[i] == s[0]) {
         count ++;
      }
   }
   return 0;
}

/** 
 * Avalia uma expressão matemática com as operações +,-,/,* e precedência com
 * parênteses.
 *
 * Esta função assume que a expressão matemática "e" é bem formada e possui 
 * apenas números inteiros.
 * @param e String com a expressão. Ex.: 1*(2+4)-1/2
 * 
 * @return Resultado da expressão
 */
float eval(char *e) {
   float res = 0;       //resultado      
   float x = 0;         //operando
   float y = 1;         //operando ancestral ou módulo
   int   i = 0;         //laço
   int   k = 0;         //auxiliar pra busca
   char lastOp = '+';   //lastOp
   char temp;           //temporário 
   int  len=strlen(e);  //Tamanho da expressão

   while (i<=len) {                    //Loop principal que percorre a string e
      char c = e[i]?e[i]:'+';          //<-Isto é um truque pra última expressão
      if (c == '(') {                  
         k = findPair(&e[i]);     
         temp =  e[i+k];               //Identificação de bloco com parentese
         e[i+k] = '\0';                //Recursivamente calcula o valor do bloco
         x = eval(&e[i+1]);            //e guarda no operando x
         e[i+k] = temp;
         i+=k;
      } else if (strchr("+-/*",c)){    //Bloco de decisão para as operações
         if ((lastOp=='/') && (x!=0)){ //Na divisão deve se cuidar divisão por 0
            x = y/x;                   //Ela utiliza o operando ancestral y     
         } else {                      //As outras operações se baseiam somente
            x = y*x;                   //No operando X * módulo Y
         } 
         if (c=='+') {                 //As operações de Soma e Substração
            res += x;                  //são as únicas a somar o operando X
            y=1;                       //ao resultado. Elas também trocam o
         } else if (c=='-') {          //módulo de Y 
            res += x;
            y=-1;
         } else {                      //Tanto multiplicação quanto divisão
            y += x;                    //Apenas armazena um operando ancestral Y
         }
         lastOp = c;
      } else if ((k = strspn(&e[i],"0123456789"))) {  //Identificação de
         x = atoi(&e[i]);                             //números comuns  
         i+=k-1;                                      //Espaços são ignorados 
      }                                               //automaticamente
      i++;               
   }               
   return res;     
}

int main(int argc, char** argv) {

   char* expression = NULL;
   size_t len = 0;
   printf("Expressão: ");
   size_t read = getline(&expression, &len, stdin);
   if (read > 0) {
       printf("%f\n",eval(expression)); //imprime o resultado
   }
   free(expression);
   return 0;
}
