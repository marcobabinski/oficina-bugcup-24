
def is_armstrong(num):
    num_str = str(num)
    soma = 0
    for c in num:
        soma += int(c) ** 3
    if soma == num:
        return True
    return False


num = int(input())
if is_armstrong(num):
    print("É número de Armstrong")
else:
    print("Não é número de Armstrong")