<?php
define("MIN", 0);
define("MAX", 999);

$numeroAleatorio = rand (MIN , MAX);
$numeroInvertido = strrev($numeroAleatorio);

$valorBase = abs($numeroAleatorio - $numeroInvertido);
$valorBaseInvertido = strrev($valorBase);

$valor1089 = $valorBase + $valorBaseInvertido;
?>
<!DOCTYPE html>
<html>
	<head>
	</head>
	<body>
		<h2> Número Mágico </h2>
		<p> <b>Número Aleatório : </b> <?= $numeroAleatorio; ?></p>
		<p> <b>Número Invertido : </b> <?= $numeroInvertido; ?></p>
		<p> <b>Número Base (Aleatório - Invertido) : </b> <?= $valorBase; ?></p>
		<p> <b>Número Base Invertido : </b> <?= $valorBaseInvertido; ?></p>
		<p> <b>VALOR FINAL (Deve ser 1089): </b> <?= $valor1089; ?></p>
	</body>
</html>