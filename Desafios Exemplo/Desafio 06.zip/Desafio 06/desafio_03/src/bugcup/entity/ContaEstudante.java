
package bugcup.entity;

public class ContaEstudante extends Conta{
    
    private final double limite = 2000;
   
   
    public boolean sacar(double valor) {
            return this.sacar(valor);
    }

    
    public boolean depositar(double valor) {
         return this.depositar(valor);
    }
    
}
