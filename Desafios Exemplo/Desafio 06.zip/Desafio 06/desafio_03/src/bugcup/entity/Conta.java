package bugcup.entity;

public abstract class Conta {

    private String numero;
    private double saldo;

    public Conta() {
    }

    public Conta(String numero, double saldo) {
        this.numero = numero;
        this.saldo = saldo;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public boolean sacar(double valor){
        if(valor <= saldo){
            this.saldo -= valor;
            return true;
        }
        return false;
        
    }

    public boolean depositar(double valor){
        if(valor>0){
            this.saldo += valor;
            return true;
        }
        return false;
    }

}
