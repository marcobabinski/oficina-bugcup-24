
package bugcup;

import bugcup.entity.ContaEstudante;


public class Bugcup {

    
     public static void main(String[] args) {
        
        ContaEstudante conta = new ContaEstudante();
        
        conta.depositar(500);
        System.out.println(conta.getSaldo());
        
        conta.sacar(500);
        System.out.println(conta.getSaldo());
        
    }
    
}
