

def palindromo(s):
    s = s.replace(" ", "#").upper()
    n = len(s)
    for i in range(n // 2):
        if s[i] == s[n - i - 1]:
            return True
    return False


texto = str(input())
if palindromo(texto):
    print("É palíndromo")
else:
    print("Não é palíndromo")