#include <stdio.h>
#include <stdlib.h>
struct Registro{
	char CPF; 
	char *CPFMasc;	
};
void preencheCPFMASC(struct Registro **reg){
	int i,j = 0;
	for(i=0; i<11; i++){ 
		if((i == 3) || (i == 7) || (i == 11)){
			reg->CPFMasc[i] = '0';
		} else {
			reg->CPFMasc[i] = reg->CPF[i]; 
			j++;
		}
		
	}
	for(i=0; i<14; i++){
		reg.CPF[i] = reg->CPFMasc[i]; 
	}
}
void mascaraCPF(struct Registro *reg){ 
	int i,j=0;
	char num[2] = {"37"};
	char acent[] = {".-"}; 
	for(i=0; i<14; i++){ 
			if(((int)num[j] - '0') == (i) || (((int)num[j - 1] - '0') + ((int)num[j - 2] - '0') + 1) == i){
				registro->CPF[i] = acent[j];
				registro->CPFMasc[i] = acent[j];
				j++;
				break; 
			}
			switch(j){
				case 2:
				case 3:
					registro->CPFMasc[i] = '*';
					break;
			}
		}
		printf("\nCPF: %s\nCPF com seguranca: %d", registro->CPF, registro->CPFMasc);
}

int main(){
	char CPF, CPFMasc;
	int i;
	struct Registro reg;
	reg.CPF = &CPF;
	reg.CPFMasc = CPFMasc; 
	reg.CPF = malloc(sizeof(char) * 14);
	reg.CPFMasc = malloc(sizeof(char) * 12); 
	printf("Digite seu CPF (Apenas numeros!): ");
	scanf("%c", reg.CPF);
	printf("%s", reg.CPF);
	preencheCPFMASC(&reg);
	mascaraCPF(reg);
	return 0;
}
