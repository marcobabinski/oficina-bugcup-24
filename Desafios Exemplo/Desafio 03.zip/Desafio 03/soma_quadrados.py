
n = int(input())
somatorio = 1
for i in range(n):
    somatorio += i**2

print(somatorio)